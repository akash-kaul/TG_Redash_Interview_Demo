# Flight delays
Data comes from [TODO: add source]

# Fixes and enhancements
## Add data loading script
## Add queries
## Connect more data - flights to airports
`Airports` vertex type has no edges connecting it to other vertex types
