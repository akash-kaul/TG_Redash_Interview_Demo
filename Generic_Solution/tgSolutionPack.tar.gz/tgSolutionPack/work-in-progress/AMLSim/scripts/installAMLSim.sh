gsql ./amlSim/scripts/create_AMLSim_schema.gsql
gsql ./amlSim/scripts/createAMLSim_load_job.gsql
gsql ./amlSim/scripts/run_AMLSim_load_job.gsql
