# Simple Entity Resolution demo with data

Remember that entity resolution is not generally a use case in itself, but is very commonly used across many types of queries.

# Fixes and enhancements
## Add data and queries to include movies/keyword/phone
