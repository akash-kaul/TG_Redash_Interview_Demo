#!/bin/bash

echo 'log cleanup, make sure services are stopped'

rm -rf /home/tigergraph/tigergraph/log/admin/*
rm -rf /home/tigergraph/tigergraph/log/dict/*
rm -rf /home/tigergraph/tigergraph/log/executor/*
rm -rf /home/tigergraph/tigergraph/log/gpe/*
rm -rf /home/tigergraph/tigergraph/log/gsql/*
rm -rf /home/tigergraph/tigergraph/log/informant/*
rm -rf /home/tigergraph/tigergraph/log/kafkaconn/*
rm -rf /home/tigergraph/tigergraph/log/nginx/*
rm -rf /home/tigergraph/tigergraph/log/ts3/*
rm -rf /home/tigergraph/tigergraph/log/zk/*
rm -rf /home/tigergraph/tigergraph/log/controller/*
rm -rf /home/tigergraph/tigergraph/log/etcd/*
rm -rf /home/tigergraph/tigergraph/log/fileLoader/*
rm -rf /home/tigergraph/tigergraph/log/gse/*
rm -rf /home/tigergraph/tigergraph/log/gui/*
rm -rf /home/tigergraph/tigergraph/log/kafka/*
rm -rf /home/tigergraph/tigergraph/log/kafkastrm-ll/*
rm -rf /home/tigergraph/tigergraph/log/restpp/*
rm -rf /home/tigergraph/tigergraph/log/ts3serv/*

