// Create a mySQL ddl script from a csv file.


